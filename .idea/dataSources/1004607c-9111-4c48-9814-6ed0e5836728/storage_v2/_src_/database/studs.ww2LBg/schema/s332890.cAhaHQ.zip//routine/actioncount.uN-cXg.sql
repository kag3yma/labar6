create function actioncount() returns trigger
    language plpgsql
as
$$
    begin
        new.amount_of_actions = (
            select count(*)
            from action
            join animal_actions on animal_actions.action_id = action.id
                                    );
        return new;
    end;
    $$;

alter function actioncount() owner to s332890;

