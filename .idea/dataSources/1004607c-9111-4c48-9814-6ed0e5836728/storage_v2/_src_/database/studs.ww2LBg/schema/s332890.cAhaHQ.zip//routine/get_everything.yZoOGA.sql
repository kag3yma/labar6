create function get_everything(idd integer)
    returns TABLE(person_name text, action_name text, animal_name text)
    language plpgsql
as
$$
    BEGIN
    return query(
        select person.name::text, action.name::text,animal.name::text
            from person
        join person_actions on person_actions.person_id = person.id
        join action on person_actions.action_id = action.id
        join animal_actions on animal_actions.action_id = action.id
        join animal on animal_actions.animal_id = animal.id
        where person.id = idd);
    end;
$$;

alter function get_everything(integer) owner to s332890;

