create procedure get_name(IN idd integer, OUT result text)
    language plpgsql
as
$$
            BEGIN
    select person.name into result
    from person where person.id = idd;
end;
$$;

alter procedure get_name(integer, out text) owner to s332890;

