create function killanimal() returns trigger
    language plpgsql
as
$$
    declare
        id int;
        name varchar;
    begin

        id = (select animal.id from animal where state = 'dead');
        name = (select animal.name from animal where state = 'dead');
        insert into dead_creatures(id, name, date_of_death) values (id, name, now());
        delete from animal where state = 'dead';
        return null;
    end;
    $$;

alter function killanimal() owner to s332890;

