create function killperson() returns trigger
    language plpgsql
as
$$
    declare
        id int;
        name varchar;
    begin

        id = (select person.id from person where state = 'dead');
        name = (select person.name from person where state = 'dead');
        insert into dead_creatures(id, name, date_of_death) values (id, name, now());
        delete from person where state = 'dead';
        return null;
    end;
    $$;

alter function killperson() owner to s332890;

