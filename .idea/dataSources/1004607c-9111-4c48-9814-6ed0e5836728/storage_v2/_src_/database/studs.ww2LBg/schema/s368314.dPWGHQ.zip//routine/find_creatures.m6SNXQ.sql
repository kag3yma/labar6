create function find_creatures(id integer)
    returns TABLE(location text, damage_type text)
    language plpgsql
as
$$
BEGIN
    SELECT area, type_of_damage INTO location, damage_type FROM "Location" L
    JOIN "Status_creatures" SC on  L.id = SC.id_locatoin
    JOIN "Damage_Guide" DG on SC.id_damage = DG.id
    WHERE SC.id_creatures = id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Creatures with id % not found', id;
    end if;
    RETURN;
END;
$$;

alter function find_creatures(integer) owner to s368314;

