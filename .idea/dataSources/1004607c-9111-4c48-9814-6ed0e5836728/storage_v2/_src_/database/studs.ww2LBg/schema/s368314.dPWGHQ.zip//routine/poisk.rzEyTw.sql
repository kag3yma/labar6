create function poisk(id_creat integer)
    returns TABLE(location character varying, type_of_damage character varying)
    language sql
as
$$ SELECT DISTINCT area, type_of_damage FROM "Location"
    JOIN "Status_creatures" on id_locatoin = "Location".id
    JOIN "Damage_Guide" on "Damage_Guide".id = id_damage
    WHERE id_creatures = id_creat $$;

alter function poisk(integer) owner to s368314;

